export const environment = {
  registerUserUrl: 'http://localhost:8080/api/users',
  registerBarmanUrl: 'http://localhost:8080/api/barmen',
  loginUrl: 'http://localhost:8080/api/users/login',
  barmenUrl: 'http://localhost:8080/api/barmen'
};
