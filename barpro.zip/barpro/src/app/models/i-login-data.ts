export interface ILoginData {
  username: string
  password: string
}
