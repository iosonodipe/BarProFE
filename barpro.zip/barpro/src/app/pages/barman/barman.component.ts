import { Component } from '@angular/core';

@Component({
  selector: 'app-barman',
  templateUrl: './barman.component.html',
  styleUrl: './barman.component.scss'
})
export class BarmanComponent {

}
